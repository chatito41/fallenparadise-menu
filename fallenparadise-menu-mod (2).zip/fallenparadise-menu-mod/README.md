# The Fallen Paradise Menu (Forge 1.12.2)

Reemplaza el menu principal (incluido el de The Betweenlands) por el menu de The Fallen Paradise.
Solo cliente, sin dependencias, sin config.

## Compilar

Necesitas Java 8 y el MDK oficial de Forge 1.12.2 (https://files.minecraftforge.net, version 1.12.2, "Mdk").

1. Descomprime el MDK en una carpeta.
2. Copia la carpeta `src` de este proyecto dentro del MDK (reemplaza `src/main` de ejemplo).
3. En la carpeta del MDK:
   - `gradlew setupDecompWorkspace`
   - `gradlew build`
4. El `.jar` queda en `build/libs/`. Ponlo en la carpeta `mods` junto con The Betweenlands.

En `build.gradle` del MDK conviene poner `version = "1.0.0"`, `group = "com.fallenparadise.menu"`
y `archivesBaseName = "fallenparadise-menu"`.

## Ajustes

- Imagen del menu: `src/main/resources/assets/fallenparadisemenu/textures/gui/menu_background.jpg` (es la imagen original, sin recomprimir).
  Si la cambias por otra version del mismo arte (distinta resolucion), los botones siguen alineados.
- Posicion de los botones: constante `BUTTONS` en `GuiFallenParadiseMenu.java`
  (pixeles sobre una imagen de referencia de 2000x1333).
- Recorte vertical en pantallas anchas: `ANCHOR_Y` (0.2 = recorta mas por abajo).

## Si no reemplaza el menu de Betweenlands

Activa el log en modo debug o busca en `logs/latest.log` la linea "Reemplazando menu principal".
Si no aparece, el menu de Betweenlands usa otra clase: ajusta `isMainMenu` en `MenuHandler.java`.

## Compilar sin instalar nada (GitHub Actions)

El proyecto ya incluye `build.gradle` y `settings.gradle` (ForgeGradle 2.3, Forge 1.12.2-14.23.5.2860).
Sube este zip a un repositorio de GitHub junto con el workflow `.github/workflows/build.yml`
y GitHub compila el `.jar` por ti (pestana Actions > ultimo run > Artifacts).
Para compilar en local con Gradle 4.9 y Java 8: `gradle setupCIWorkspace build`.
