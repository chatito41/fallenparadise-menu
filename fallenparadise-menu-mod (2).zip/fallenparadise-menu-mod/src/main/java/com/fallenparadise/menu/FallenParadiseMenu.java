package com.fallenparadise.menu;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Reemplaza el menu principal (incluido el de The Betweenlands) por el menu de "The Fallen Paradise".
 */
@Mod(
        modid = FallenParadiseMenu.MODID,
        name = FallenParadiseMenu.NAME,
        version = FallenParadiseMenu.VERSION,
        acceptedMinecraftVersions = "[1.12.2]",
        clientSideOnly = true
)
public class FallenParadiseMenu {

    public static final String MODID = "fallenparadisemenu";
    public static final String NAME = "The Fallen Paradise Menu";
    public static final String VERSION = "1.0.0";

    public static final Logger LOGGER = LogManager.getLogger(MODID);

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new MenuHandler());
    }
}
