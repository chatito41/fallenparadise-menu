package com.fallenparadise.menu;

import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.GuiModList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

/**
 * Menu principal: usa la imagen como fondo (los botones ya vienen dibujados en la imagen)
 * y coloca zonas clicables exactamente encima de ellos.
 *
 * Rendimiento: un solo quad por frame, sin asignar memoria en drawScreen; el layout se calcula
 * unicamente al abrir o redimensionar la ventana.
 */
@SideOnly(Side.CLIENT)
public class GuiFallenParadiseMenu extends GuiScreen {

    private static final ResourceLocation BACKGROUND =
            new ResourceLocation(FallenParadiseMenu.MODID, "textures/gui/menu_background.jpg");

    /**
     * Que parte de la imagen que sobra se recorta por arriba (0 = todo por abajo, 1 = todo por arriba).
     * 0.2 mantiene el titulo visible en pantallas 16:9.
     */
    private static final float ANCHOR_Y = 0.2F;

    /** Tamano de referencia sobre el que se midieron los botones (no tiene que ser el tamano real). */
    private static final float REF_W = 2000F;
    private static final float REF_H = 1333F;

    /** x1, y1, x2, y2 en pixeles de referencia. Orden: Singleplayer, Multiplayer, Options, Mods, Quit. */
    private static final int[][] BUTTONS = {
            {765, 567, 1005, 630},
            {1020, 567, 1235, 630},
            {850, 672, 1007, 738},
            {1020, 672, 1140, 738},
            {903, 780, 1092, 843}
    };

    /** Tamano real de la textura; se lee una sola vez (solo el encabezado, sin decodificar la imagen). */
    private static int texW = 0;
    private static int texH = 0;

    // Layout cacheado (se recalcula en initGui, que Minecraft llama al abrir y al redimensionar).
    private int bgX, bgY, bgW, bgH;
    private final int[][] rects = new int[BUTTONS.length][4];

    @Override
    public void initGui() {
        loadTextureSize();
        computeLayout();
    }

    private void loadTextureSize() {
        if (texW > 0 && texH > 0) {
            return;
        }
        try (InputStream in = mc.getResourceManager().getResource(BACKGROUND).getInputStream();
             ImageInputStream iis = ImageIO.createImageInputStream(in)) {
            Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);
            if (readers.hasNext()) {
                ImageReader reader = readers.next();
                try {
                    reader.setInput(iis, true, true);
                    texW = reader.getWidth(0);
                    texH = reader.getHeight(0);
                } finally {
                    reader.dispose();
                }
            }
        } catch (Exception e) {
            FallenParadiseMenu.LOGGER.error("No se pudo leer el tamano del fondo del menu", e);
        }
        if (texW <= 0 || texH <= 0) {
            texW = (int) REF_W;
            texH = (int) REF_H;
        }
    }

    private void computeLayout() {
        float scale = Math.max((float) width / texW, (float) height / texH);
        float dw = texW * scale;
        float dh = texH * scale;
        float dx = (width - dw) / 2F;
        float dy = -(dh - height) * ANCHOR_Y;

        bgX = Math.round(dx);
        bgY = Math.round(dy);
        bgW = Math.round(dw);
        bgH = Math.round(dh);

        for (int i = 0; i < BUTTONS.length; i++) {
            int[] b = BUTTONS[i];
            rects[i][0] = Math.round(dx + b[0] / REF_W * dw);
            rects[i][1] = Math.round(dy + b[1] / REF_H * dh);
            rects[i][2] = Math.round(dx + b[2] / REF_W * dw);
            rects[i][3] = Math.round(dy + b[3] / REF_H * dh);
        }
    }

    private boolean isOver(int index, int mouseX, int mouseY) {
        int[] r = rects[index];
        return mouseX >= r[0] && mouseX <= r[2] && mouseY >= r[1] && mouseY <= r[3];
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GlStateManager.disableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1F, 1F, 1F, 1F);
        mc.getTextureManager().bindTexture(BACKGROUND);
        // Filtro suave: la imagen es mas grande que la pantalla y con NEAREST se veria dentada.
        // (Se fija en cada frame porque el filtro se pierde si se recargan los recursos con F3+T.)
        GlStateManager.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GlStateManager.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);

        drawScaledCustomSizeModalRect(bgX, bgY, 0F, 0F, texW, texH, bgW, bgH, texW, texH);

        // Resaltado al pasar el raton por encima de un boton.
        for (int i = 0; i < BUTTONS.length; i++) {
            if (isOver(i, mouseX, mouseY)) {
                int[] r = rects[i];
                drawRect(r[0], r[1], r[2], r[3], 0x33FFFFFF);
                break;
            }
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton != 0) {
            return;
        }
        for (int i = 0; i < BUTTONS.length; i++) {
            if (isOver(i, mouseX, mouseY)) {
                mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                onButton(i);
                return;
            }
        }
    }

    private void onButton(int index) {
        switch (index) {
            case 0:
                mc.displayGuiScreen(new GuiWorldSelection(this));
                break;
            case 1:
                mc.displayGuiScreen(new GuiMultiplayer(this));
                break;
            case 2:
                mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
                break;
            case 3:
                mc.displayGuiScreen(new GuiModList(this));
                break;
            case 4:
                mc.shutdown();
                break;
            default:
                break;
        }
    }

    /** En el menu principal Esc no debe cerrar la pantalla. */
    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
