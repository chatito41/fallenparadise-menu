package com.fallenparadise.menu;

import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class MenuHandler {

    /**
     * Prioridad LOWEST: corre despues de que The Betweenlands (u otro mod) haya puesto su propio
     * menu, asi que nuestro menu es el que queda al final.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onGuiOpen(GuiOpenEvent event) {
        GuiScreen gui = event.getGui();
        if (gui == null || gui instanceof GuiFallenParadiseMenu) {
            return;
        }
        if (isMainMenu(gui)) {
            FallenParadiseMenu.LOGGER.info("Reemplazando menu principal: {}", gui.getClass().getName());
            event.setGui(new GuiFallenParadiseMenu());
        } else if (gui.getClass().getName().toLowerCase().contains("menu")) {
            // Ayuda para depurar: si el menu de Betweenlands no se reemplaza, aqui aparece su clase real.
            FallenParadiseMenu.LOGGER.debug("Pantalla con 'menu' en el nombre (no reemplazada): {}", gui.getClass().getName());
        }
    }

    private static boolean isMainMenu(GuiScreen gui) {
        if (gui instanceof GuiMainMenu) {
            return true;
        }
        String name = gui.getClass().getName().toLowerCase();
        return name.contains("thebetweenlands") && name.contains("mainmenu");
    }
}
